﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basketball_Scoreboard
{
    public partial class Form1 : Form
    {
        int gameCountdown = 60;
        Timer gameTimer = new Timer();
        int timeoutDuration = 30;
        Timer timeoutTimer = new Timer();
        bool isTimeoutActive = false;
        bool isDisplayingTimeout = false;
        int scoreTeam1 = 0, scoreTeam2 = 0;
        int foulsTeam1 = 0, foulsTeam2 = 0;
        int currentQuarter = 1;
        const int totalQuarters = 4;
        bool isGameStarted = false;

        public Form1()
        {
            InitializeComponent();
            InitializeGameTimer();
        }

        private void InitializeGameTimer()
        {
            gameTimer.Interval = 1000;
            gameTimer.Tick += timerGame_Tick;
        }

        private bool CheckGameStarted()
        {
            if (!isGameStarted)
            {
                MessageBox.Show("Silakan mulai permainan terlebih dahulu dengan menekan tombol Start!", "Peringatan");
                return false;
            }
            return true;
        }

        private void timerGame_Tick(object sender, EventArgs e)
        {
            if (gameCountdown > 0)
            {
                gameCountdown--;
                if (!isDisplayingTimeout) // Update tampilan timer hanya jika timeout tidak aktif
                {
                    lblTimer.Text = TimeSpan.FromSeconds(gameCountdown).ToString(@"mm\:ss");
                }
            }
            else
            {
                gameTimer.Stop();
                MessageBox.Show($"Quarter {currentQuarter} selesai!", "Informasi");
                NextQuarter(); // Pindah ke quarter berikutnya
            }
        }

        private void btnChangeTeamNames_Click(object sender, EventArgs e)
        {
            lblTeam1Name.Text = txtTeam1Name.Text;
            lblTeam2Name.Text = txtTeam2Name.Text;
        }

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            // Matikan timeout jika sedang aktif
            if (isTimeoutActive)
            {
                timeoutTimer.Stop();
                isTimeoutActive = false; // Timeout dinonaktifkan
                isDisplayingTimeout = false; // Kembalikan tampilan ke gameTimer
            }

            // Langsung tampilkan waktu gameTimer di lblTimer
            lblTimer.Text = TimeSpan.FromSeconds(gameCountdown).ToString(@"mm\:ss");

            // Mulai gameTimer
            if (!gameTimer.Enabled)
            {
                gameTimer.Start();
            }

            // Tandai game sebagai dimulai
            isGameStarted = true;


        }
        private void NextQuarter()
        {
            if (currentQuarter < totalQuarters) // Cek jika belum mencapai quarter ke-4
            {
                currentQuarter++; // Naikkan quarter
                lblQuarter.Text = $"Quarter {currentQuarter}";

                // Reset timer ke awal (contoh: 10 menit per quarter)
                gameCountdown = 60; // 10 menit
                lblTimer.Text = "01:00";

                // Mulai ulang game timer
                gameTimer.Start();
            }
            else
            {
                gameTimer.Stop();
                MessageBox.Show("Game telah selesai!", "Game Over");
            }
        }


        private void btnAddScoreTeam1_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;

            scoreTeam1++;
            lblScoreTeam1.Text = scoreTeam1.ToString();
        }


        private void btnAddScoreTeam2_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;

            scoreTeam2++;
            lblScoreTeam2.Text = scoreTeam2.ToString();
        }

        private void btnAddFoul1_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;

            foulsTeam1++;
            if (foulsTeam1 >= 5)
                lblFoulsTeam1.Text = "P";
            else
                lblFoulsTeam1.Text = foulsTeam1.ToString();
        }

        private void btnAddFoul2_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;

            foulsTeam2++;
            if (foulsTeam2 >= 5)
                lblFoulsTeam2.Text = "P";
            else
                lblFoulsTeam2.Text = foulsTeam2.ToString();
        }

        private void timerTimeout_Tick(object sender, EventArgs e)
        {
            if (timeoutDuration > 0)
            {
                timeoutDuration--;
                lblTimer.Text = TimeSpan.FromSeconds(timeoutDuration).ToString(@"mm\:ss"); // Tampilkan timeout
            }
            else
            {
                timeoutTimer.Stop(); // Timeout selesai
                isTimeoutActive = false;
                isDisplayingTimeout = false; // Kembalikan tampilan ke waktu game timer
            }
        }

        private void btnTimeoutTeam1_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;

            if (!isTimeoutActive)
            {
                timeoutDuration = 30; // Durasi timeout 60 detik
                isTimeoutActive = true;
                isDisplayingTimeout = true; // Tampilkan timeout di lblTimer

                timeoutTimer.Tick -= timerTimeout_Tick;
                timeoutTimer.Tick += timerTimeout_Tick;

                timeoutTimer.Interval = 1000;
                timeoutTimer.Start();
            }
        }

        private void btnTimeoutTeam2_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;

            if (!isTimeoutActive)
            {
                timeoutDuration = 30;
                isTimeoutActive = true;
                isDisplayingTimeout = true;

                timeoutTimer.Tick -= timerTimeout_Tick;
                timeoutTimer.Tick += timerTimeout_Tick;

                timeoutTimer.Interval = 1000;
                timeoutTimer.Start();
            }
        }

        private void btnResetGame_Click(object sender, EventArgs e)
        {
            if (!CheckGameStarted()) return;
            // Hentikan semua timer
            gameTimer.Stop();
            timeoutTimer.Stop();

            // Reset status timeout
            isTimeoutActive = false;
            isDisplayingTimeout = false;
            timeoutDuration = 30;

            // Reset waktu game
            gameCountdown = 60; // Waktu awal 60 detik
            lblTimer.Text = "01:00";

            // Reset quarter
            currentQuarter = 1;
            lblQuarter.Text = "Quarter 1";

            // Reset skor dan fouls
            scoreTeam1 = 0;
            scoreTeam2 = 0;
            foulsTeam1 = 0;
            foulsTeam2 = 0;

            lblScoreTeam1.Text = "0";
            lblScoreTeam2.Text = "0";
            lblFoulsTeam1.Text = "0";
            lblFoulsTeam2.Text = "0";

            // Reset nama tim
            txtTeam1Name.Text = "";
            txtTeam2Name.Text = "";
            lblTeam1Name.Text = "Team 1";
            lblTeam2Name.Text = "Team 2";
        }

    }
}
