﻿namespace Basketball_Scoreboard
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTeam1Name = new System.Windows.Forms.Label();
            this.lblTeam2Name = new System.Windows.Forms.Label();
            this.txtTeam1Name = new System.Windows.Forms.TextBox();
            this.txtTeam2Name = new System.Windows.Forms.TextBox();
            this.lblScoreTeam1 = new System.Windows.Forms.Label();
            this.lblScoreTeam2 = new System.Windows.Forms.Label();
            this.btnAddScoreTeam1 = new System.Windows.Forms.Button();
            this.btnAddScoreTeam2 = new System.Windows.Forms.Button();
            this.lblFoulsTeam1 = new System.Windows.Forms.Label();
            this.lblFoulsTeam2 = new System.Windows.Forms.Label();
            this.btnAddFoul1 = new System.Windows.Forms.Button();
            this.btnAddFoul2 = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.lblQuarter = new System.Windows.Forms.Label();
            this.timerGame = new System.Windows.Forms.Timer(this.components);
            this.timerTimeout = new System.Windows.Forms.Timer(this.components);
            this.btnTimeoutTeam1 = new System.Windows.Forms.Button();
            this.btnTimeoutTeam2 = new System.Windows.Forms.Button();
            this.btnStartGame = new System.Windows.Forms.Button();
            this.btnResetGame = new System.Windows.Forms.Button();
            this.btnChangeTeamNames = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTeam1Name
            // 
            this.lblTeam1Name.AutoSize = true;
            this.lblTeam1Name.Font = new System.Drawing.Font("Roboto", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam1Name.ForeColor = System.Drawing.Color.White;
            this.lblTeam1Name.Location = new System.Drawing.Point(60, 134);
            this.lblTeam1Name.Name = "lblTeam1Name";
            this.lblTeam1Name.Size = new System.Drawing.Size(157, 58);
            this.lblTeam1Name.TabIndex = 0;
            this.lblTeam1Name.Text = "label1";
            // 
            // lblTeam2Name
            // 
            this.lblTeam2Name.AutoSize = true;
            this.lblTeam2Name.Font = new System.Drawing.Font("Roboto", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam2Name.ForeColor = System.Drawing.Color.White;
            this.lblTeam2Name.Location = new System.Drawing.Point(624, 134);
            this.lblTeam2Name.Name = "lblTeam2Name";
            this.lblTeam2Name.Size = new System.Drawing.Size(157, 58);
            this.lblTeam2Name.TabIndex = 1;
            this.lblTeam2Name.Text = "label2";
            // 
            // txtTeam1Name
            // 
            this.txtTeam1Name.BackColor = System.Drawing.Color.Black;
            this.txtTeam1Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTeam1Name.Location = new System.Drawing.Point(0, 195);
            this.txtTeam1Name.Name = "txtTeam1Name";
            this.txtTeam1Name.Size = new System.Drawing.Size(195, 20);
            this.txtTeam1Name.TabIndex = 2;
            // 
            // txtTeam2Name
            // 
            this.txtTeam2Name.BackColor = System.Drawing.Color.Black;
            this.txtTeam2Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTeam2Name.Location = new System.Drawing.Point(634, 198);
            this.txtTeam2Name.Name = "txtTeam2Name";
            this.txtTeam2Name.Size = new System.Drawing.Size(239, 20);
            this.txtTeam2Name.TabIndex = 3;
            // 
            // lblScoreTeam1
            // 
            this.lblScoreTeam1.AutoSize = true;
            this.lblScoreTeam1.Font = new System.Drawing.Font("LCDMono2", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreTeam1.ForeColor = System.Drawing.Color.Lime;
            this.lblScoreTeam1.Location = new System.Drawing.Point(95, 243);
            this.lblScoreTeam1.Name = "lblScoreTeam1";
            this.lblScoreTeam1.Size = new System.Drawing.Size(62, 59);
            this.lblScoreTeam1.TabIndex = 4;
            this.lblScoreTeam1.Text = "0";
          
            // 
            // lblScoreTeam2
            // 
            this.lblScoreTeam2.AutoSize = true;
            this.lblScoreTeam2.Font = new System.Drawing.Font("LCDMono2", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreTeam2.ForeColor = System.Drawing.Color.Lime;
            this.lblScoreTeam2.Location = new System.Drawing.Point(666, 243);
            this.lblScoreTeam2.Name = "lblScoreTeam2";
            this.lblScoreTeam2.Size = new System.Drawing.Size(62, 59);
            this.lblScoreTeam2.TabIndex = 5;
            this.lblScoreTeam2.Text = "0";
            
            // 
            // btnAddScoreTeam1
            // 
            this.btnAddScoreTeam1.BackColor = System.Drawing.Color.Black;
            this.btnAddScoreTeam1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddScoreTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddScoreTeam1.ForeColor = System.Drawing.Color.Red;
            this.btnAddScoreTeam1.Location = new System.Drawing.Point(83, 308);
            this.btnAddScoreTeam1.Name = "btnAddScoreTeam1";
            this.btnAddScoreTeam1.Size = new System.Drawing.Size(85, 23);
            this.btnAddScoreTeam1.TabIndex = 6;
            this.btnAddScoreTeam1.Text = "Add Score";
            this.btnAddScoreTeam1.UseVisualStyleBackColor = false;
            this.btnAddScoreTeam1.Click += new System.EventHandler(this.btnAddScoreTeam1_Click);
            // 
            // btnAddScoreTeam2
            // 
            this.btnAddScoreTeam2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddScoreTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddScoreTeam2.ForeColor = System.Drawing.Color.Red;
            this.btnAddScoreTeam2.Location = new System.Drawing.Point(654, 308);
            this.btnAddScoreTeam2.Name = "btnAddScoreTeam2";
            this.btnAddScoreTeam2.Size = new System.Drawing.Size(85, 23);
            this.btnAddScoreTeam2.TabIndex = 7;
            this.btnAddScoreTeam2.Text = "Add Score 2";
            this.btnAddScoreTeam2.UseVisualStyleBackColor = true;
            this.btnAddScoreTeam2.Click += new System.EventHandler(this.btnAddScoreTeam2_Click);
            // 
            // lblFoulsTeam1
            // 
            this.lblFoulsTeam1.AutoSize = true;
            this.lblFoulsTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoulsTeam1.ForeColor = System.Drawing.Color.Red;
            this.lblFoulsTeam1.Location = new System.Drawing.Point(114, 363);
            this.lblFoulsTeam1.Name = "lblFoulsTeam1";
            this.lblFoulsTeam1.Size = new System.Drawing.Size(25, 25);
            this.lblFoulsTeam1.TabIndex = 8;
            this.lblFoulsTeam1.Text = "0";
           
            // 
            // lblFoulsTeam2
            // 
            this.lblFoulsTeam2.AutoSize = true;
            this.lblFoulsTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoulsTeam2.ForeColor = System.Drawing.Color.Red;
            this.lblFoulsTeam2.Location = new System.Drawing.Point(689, 363);
            this.lblFoulsTeam2.Name = "lblFoulsTeam2";
            this.lblFoulsTeam2.Size = new System.Drawing.Size(25, 25);
            this.lblFoulsTeam2.TabIndex = 9;
            this.lblFoulsTeam2.Text = "0";
            // 
            // btnAddFoul1
            // 
            this.btnAddFoul1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddFoul1.ForeColor = System.Drawing.Color.Yellow;
            this.btnAddFoul1.Location = new System.Drawing.Point(93, 391);
            this.btnAddFoul1.Name = "btnAddFoul1";
            this.btnAddFoul1.Size = new System.Drawing.Size(75, 23);
            this.btnAddFoul1.TabIndex = 10;
            this.btnAddFoul1.Text = "Add Foul";
            this.btnAddFoul1.UseVisualStyleBackColor = true;
            this.btnAddFoul1.Click += new System.EventHandler(this.btnAddFoul1_Click);
            // 
            // btnAddFoul2
            // 
            this.btnAddFoul2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddFoul2.ForeColor = System.Drawing.Color.Yellow;
            this.btnAddFoul2.Location = new System.Drawing.Point(664, 391);
            this.btnAddFoul2.Name = "btnAddFoul2";
            this.btnAddFoul2.Size = new System.Drawing.Size(75, 23);
            this.btnAddFoul2.TabIndex = 11;
            this.btnAddFoul2.Text = "Add Foul";
            this.btnAddFoul2.UseVisualStyleBackColor = true;
            this.btnAddFoul2.Click += new System.EventHandler(this.btnAddFoul2_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Font = new System.Drawing.Font("LCDMono2", 80F, System.Drawing.FontStyle.Bold);
            this.lblTimer.ForeColor = System.Drawing.Color.Lime;
            this.lblTimer.Location = new System.Drawing.Point(252, 198);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(330, 96);
            this.lblTimer.TabIndex = 12;
            this.lblTimer.Text = "00:00";
            // 
            // lblQuarter
            // 
            this.lblQuarter.AutoSize = true;
            this.lblQuarter.Font = new System.Drawing.Font("Roboto Lt", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuarter.ForeColor = System.Drawing.Color.Yellow;
            this.lblQuarter.Location = new System.Drawing.Point(360, 319);
            this.lblQuarter.Name = "lblQuarter";
            this.lblQuarter.Size = new System.Drawing.Size(100, 23);
            this.lblQuarter.TabIndex = 13;
            this.lblQuarter.Text = "Quarter 1";
           
            // 
            // timerGame
            // 
            this.timerGame.Tick += new System.EventHandler(this.timerGame_Tick);
            // 
            // timerTimeout
            // 
            this.timerTimeout.Tick += new System.EventHandler(this.timerTimeout_Tick);
            // 
            // btnTimeoutTeam1
            // 
            this.btnTimeoutTeam1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTimeoutTeam1.ForeColor = System.Drawing.Color.Red;
            this.btnTimeoutTeam1.Location = new System.Drawing.Point(93, 435);
            this.btnTimeoutTeam1.Name = "btnTimeoutTeam1";
            this.btnTimeoutTeam1.Size = new System.Drawing.Size(75, 23);
            this.btnTimeoutTeam1.TabIndex = 14;
            this.btnTimeoutTeam1.Text = "Timeout";
            this.btnTimeoutTeam1.UseVisualStyleBackColor = true;
            this.btnTimeoutTeam1.Click += new System.EventHandler(this.btnTimeoutTeam1_Click);
            // 
            // btnTimeoutTeam2
            // 
            this.btnTimeoutTeam2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTimeoutTeam2.ForeColor = System.Drawing.Color.Red;
            this.btnTimeoutTeam2.Location = new System.Drawing.Point(664, 435);
            this.btnTimeoutTeam2.Name = "btnTimeoutTeam2";
            this.btnTimeoutTeam2.Size = new System.Drawing.Size(75, 23);
            this.btnTimeoutTeam2.TabIndex = 15;
            this.btnTimeoutTeam2.Text = "Timeout";
            this.btnTimeoutTeam2.UseVisualStyleBackColor = true;
            this.btnTimeoutTeam2.Click += new System.EventHandler(this.btnTimeoutTeam2_Click);
            // 
            // btnStartGame
            // 
            this.btnStartGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStartGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartGame.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnStartGame.Location = new System.Drawing.Point(375, 161);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(85, 27);
            this.btnStartGame.TabIndex = 16;
            this.btnStartGame.Text = "Start Game";
            this.btnStartGame.UseVisualStyleBackColor = true;
            this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
            // 
            // btnResetGame
            // 
            this.btnResetGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnResetGame.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnResetGame.Location = new System.Drawing.Point(375, 496);
            this.btnResetGame.Name = "btnResetGame";
            this.btnResetGame.Size = new System.Drawing.Size(75, 23);
            this.btnResetGame.TabIndex = 17;
            this.btnResetGame.Text = "Restart";
            this.btnResetGame.UseVisualStyleBackColor = true;
            this.btnResetGame.Click += new System.EventHandler(this.btnResetGame_Click);
            // 
            // btnChangeTeamNames
            // 
            this.btnChangeTeamNames.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChangeTeamNames.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeTeamNames.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnChangeTeamNames.Location = new System.Drawing.Point(375, 28);
            this.btnChangeTeamNames.Name = "btnChangeTeamNames";
            this.btnChangeTeamNames.Size = new System.Drawing.Size(85, 27);
            this.btnChangeTeamNames.TabIndex = 18;
            this.btnChangeTeamNames.Text = "Change Team";
            this.btnChangeTeamNames.UseVisualStyleBackColor = true;
            this.btnChangeTeamNames.Click += new System.EventHandler(this.btnChangeTeamNames_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Akira Expanded", 38F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(31, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 54);
            this.label1.TabIndex = 19;
            this.label1.Text = "HOME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Akira Expanded", 38F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(575, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 54);
            this.label2.TabIndex = 20;
            this.label2.Text = "GUEST";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Basketball_Scoreboard.Properties.Resources.Logo_Prodi_Mono_Tone_gold_1;
            this.pictureBox3.Location = new System.Drawing.Point(318, 70);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(197, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Basketball_Scoreboard.Properties.Resources.ENBEA;
            this.pictureBox2.Location = new System.Drawing.Point(418, 374);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(97, 95);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Basketball_Scoreboard.Properties.Resources.pngwing_com__8_;
            this.pictureBox1.Location = new System.Drawing.Point(308, 374);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(95, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
           
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(872, 545);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnChangeTeamNames);
            this.Controls.Add(this.btnResetGame);
            this.Controls.Add(this.btnStartGame);
            this.Controls.Add(this.btnTimeoutTeam2);
            this.Controls.Add(this.btnTimeoutTeam1);
            this.Controls.Add(this.lblQuarter);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.btnAddFoul2);
            this.Controls.Add(this.btnAddFoul1);
            this.Controls.Add(this.lblFoulsTeam2);
            this.Controls.Add(this.lblFoulsTeam1);
            this.Controls.Add(this.btnAddScoreTeam2);
            this.Controls.Add(this.btnAddScoreTeam1);
            this.Controls.Add(this.lblScoreTeam2);
            this.Controls.Add(this.lblScoreTeam1);
            this.Controls.Add(this.txtTeam2Name);
            this.Controls.Add(this.txtTeam1Name);
            this.Controls.Add(this.lblTeam2Name);
            this.Controls.Add(this.lblTeam1Name);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTeam1Name;
        private System.Windows.Forms.Label lblTeam2Name;
        private System.Windows.Forms.TextBox txtTeam1Name;
        private System.Windows.Forms.TextBox txtTeam2Name;
        private System.Windows.Forms.Label lblScoreTeam1;
        private System.Windows.Forms.Label lblScoreTeam2;
        private System.Windows.Forms.Button btnAddScoreTeam1;
        private System.Windows.Forms.Button btnAddScoreTeam2;
        private System.Windows.Forms.Label lblFoulsTeam1;
        private System.Windows.Forms.Label lblFoulsTeam2;
        private System.Windows.Forms.Button btnAddFoul1;
        private System.Windows.Forms.Button btnAddFoul2;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label lblQuarter;
        private System.Windows.Forms.Timer timerGame;
        private System.Windows.Forms.Timer timerTimeout;
        private System.Windows.Forms.Button btnTimeoutTeam1;
        private System.Windows.Forms.Button btnTimeoutTeam2;
        private System.Windows.Forms.Button btnStartGame;
        private System.Windows.Forms.Button btnResetGame;
        private System.Windows.Forms.Button btnChangeTeamNames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

